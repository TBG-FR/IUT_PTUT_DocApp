
(Après avoir installé composer ? Non nécessaire ?)

Extraire dans C:\Users\{NOM_UTILISATEUR}\AppData\Roaming\Composer\vendor\bin

Ajouter dans PATH : 'C:\Users\{NOM_UTILISATEUR}\AppData\Roaming\Composer\vendor\bin'

La commande "composer" devrait désormais fonctionner n'importe où
(Si oui, faire "composer install" après s'être placé dans '/site/' )